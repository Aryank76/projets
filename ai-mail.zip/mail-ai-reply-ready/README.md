# Mail AI Reply (ready to load)

1. Chrome -> chrome://extensions -> Developer mode ON -> Load unpacked -> select the `extension` folder.
2. Open Gmail, refresh (F5), open an email, click Reply, click the AI Reply button.

The API key is already inside extension/config.js. Don't share or upload this folder.
After editing config.js: click Reload on the extension and refresh Gmail.
