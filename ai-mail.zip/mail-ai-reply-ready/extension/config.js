// >>> THE ONLY THING YOU EDIT: paste your Gemini API key between the quotes. <<<
// Get one free at https://aistudio.google.com/apikey
// This file is git-ignored, so the key is never committed.
const GEMINI_API_KEY = "AQ.Ab8RN6Kl5LrProScnBpuJrTLDMtZTPTkl7ldKSHx1xqWELlR9g";

// Tried in order; the next one is used if a model fails.
const GEMINI_MODELS = ["gemini-3.5-flash", "gemini-2.5-flash", "gemini-2.0-flash"];
