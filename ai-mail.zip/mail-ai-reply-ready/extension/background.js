importScripts("config.js"); // defines GEMINI_API_KEY and GEMINI_MODELS

const BASE = "https://generativelanguage.googleapis.com/v1beta/models/";

function buildPrompt({ email, subject, tone }) {
  return `You are an email assistant. Write a ${tone || "professional"} reply to the email below.
Rules: output ONLY the reply body, no subject line, no explanations, no markdown.
Start with a greeting and end with a short sign-off. Do not invent facts or commitments.

Subject: ${subject || ""}

Email:
${String(email).slice(0, 8000)}`;
}

async function generate(prompt) {
  const key = String(typeof GEMINI_API_KEY === "undefined" ? "" : GEMINI_API_KEY)
    .trim().replace(/^["']|["']$/g, "");
  if (!key) {
    throw new Error("The key in extension/config.js is empty. Put your key between the quotes, save, reload the extension, refresh Gmail.");
  }
  if (key.includes("PASTE_YOUR_KEY")) {
    throw new Error("config.js still contains the text PASTE_YOUR_KEY_HERE. DELETE that text and put only your key there (it starts with AIza). Then save, reload the extension, refresh Gmail.");
  }
  const errors = [];
  for (const model of GEMINI_MODELS) {
    try {
      const res = await fetch(`${BASE}${model}:generateContent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.7 },
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { errors.push(`${model}: ${data.error?.message || "HTTP " + res.status}`); continue; }
      const parts = data.candidates?.[0]?.content?.parts || [];
      const text = parts.filter((p) => p.text && !p.thought).map((p) => p.text).join("").trim();
      if (text) return text;
      errors.push(`${model}: empty reply`);
    } catch (e) {
      errors.push(`${model}: ${e.message}`);
    }
  }
  throw new Error("All models failed: " + errors.join(" | "));
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "generate-reply") return;
  generate(buildPrompt(msg.payload))
    .then((reply) => sendResponse({ ok: true, reply }))
    .catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
  return true; // async response
});
