const BOX_SEL = 'div[role="textbox"][g_editable="true"]';
const TONES = ["professional", "friendly", "short and direct", "formal", "apologetic"];

function findComposeBox(fromEl) {
  let el = fromEl, box = null;
  while (el && !box) { box = el.querySelector(BOX_SEL); el = el.parentElement; }
  return box;
}

function getEmailContext() {
  const msgs = document.querySelectorAll("div.a3s");
  const last = msgs[msgs.length - 1];
  return {
    email: last ? last.innerText.trim().slice(0, 8000) : "",
    subject: document.querySelector("h2.hP")?.innerText || "",
  };
}

function insertAtStart(box, text) {
  box.focus();
  const range = document.createRange();
  range.selectNodeContents(box);
  range.collapse(true);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);
  document.execCommand("insertText", false, text + "\n\n");
}

function makeButton(bar) {
  const wrap = document.createElement("span");
  wrap.className = "ai-reply-wrap";

  const select = document.createElement("select");
  select.className = "ai-reply-tone";
  TONES.forEach((t) => select.add(new Option(t, t)));

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "ai-reply-btn";
  btn.textContent = "✨ AI Reply";

  btn.addEventListener("click", () => {
    const { email, subject } = getEmailContext();
    if (!email) return alert("Open an email thread first so I can read the message.");
    const box = findComposeBox(bar);
    if (!box) return alert("Reply box not found. Click Reply first.");

    btn.disabled = true;
    btn.textContent = "Thinking…";
    const done = () => { btn.disabled = false; btn.textContent = "✨ AI Reply"; };

    chrome.runtime.sendMessage(
      { type: "generate-reply", payload: { email, subject, tone: select.value } },
      (resp) => {
        done();
        if (chrome.runtime.lastError) return alert("Extension was reloaded. Refresh the Gmail tab.");
        if (!resp?.ok) return alert("AI reply failed: " + (resp?.error || "unknown error"));
        insertAtStart(box, resp.reply);
      }
    );
  });

  wrap.append(select, btn);
  return wrap;
}

function addButtons() {
  // div.dC is the toolbar group that holds Gmail's Send button
  document.querySelectorAll("div.dC").forEach((bar) => {
    if (bar.parentElement?.querySelector(".ai-reply-wrap")) return;
    bar.insertAdjacentElement("afterend", makeButton(bar));
  });
}

let timer;
new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(addButtons, 300); })
  .observe(document.body, { childList: true, subtree: true });
addButtons();
